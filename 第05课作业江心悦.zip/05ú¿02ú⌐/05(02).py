import turtle as t
t.speed(100)
t.hideturtle()

def a(x,y,m):
    t.penup()
    t.goto(x,y)
    t.setheading(90)
    t.color("red")
    t.pendown()
    t.begin_fill()
    t.circle(m)
    t.end_fill()
    
def b(x,y,m):
    t.penup()
    t.goto(x,y)
    t.setheading(90)
    t.color("white")
    t.pendown()
    t.begin_fill()
    t.circle(m)
    t.end_fill()

a(0,0,150)
a(0,0,-150)
b(-30,0,120)
b(30,0,-120)
a(-60,0,90)
a(60,0,-90)

t.penup()
t.goto(-90,0)
t.setheading(90)
t.color("blue")
t.pendown()
t.begin_fill()
t.circle(60)
t.end_fill()

t.penup()
t.goto(-210,20)
t.setheading(0)
t.color("white")
t.pendown()
t.begin_fill()
i=0
for i in range(5):
    t.forward(116)
    t.right(180-36)
    i+=1
t.end_fill()

t.penup()
t.goto(90,0)
t.setheading(90)
t.color("yellow")
t.pendown()
t.begin_fill()
t.circle(-60)
t.end_fill()

def c(x,y,n,m):
    t.penup()
    t.goto(x,y)
    t.setheading(90)
    t.color(n)
    t.pendown()
    t.begin_fill()
    t.circle(m)
    t.end_fill()

c(100,20,"white",-20)
c(160,20,"white",-20)
c(100,20,"black",-15)
c(160,20,"black",-15)

t.penup()
t.goto(150,-35)
t.setheading(0)
t.color("brown")
t.pendown()
t.circle(30,60)
t.circle(30,-120)
