import turtle as t
t.speed(100)
t.hideturtle()
t.pensize(2)

t.color("black","blue")
t.begin_fill()
t.goto(-300,150)
t.goto(100,50)
t.goto(0,0)
t.end_fill()
t.goto(-30,-125)
t.goto(-50,-50)
t.goto(-300,150)
t.begin_fill()
t.goto(-125,-125)
t.goto(-50,-50)
t.end_fill()
t.begin_fill()
t.goto(-30,-125)
t.goto(-85,-85)
t.end_fill()

def a(x,y,a,b):
    t.penup()
    t.goto(x,y)
    t.pendown()
    t.goto(a,b)
a(75,25,200,0)
a(50,-5,250,-30)
a(10,-80,100,-150)
a(-80,-125,120,-200)

t.penup()
t.color("red")
t.goto(250,200)
t.setheading(0)
t.pendown()
t.begin_fill()
t.circle(50)
t.end_fill()



